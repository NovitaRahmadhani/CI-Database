<div class="col-md-12">
    <h3>
        List Pasien
    </h3>
    <table class="table">
        <thead>
            <tr>
                <th>Kode</th><th>Nama</th><th>Gender</th><th>Tempat Lahir</th><th>Tanggal Lahir</th>
                <th>Email</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $nomor =1;
        foreach($pasien as $pasien) : ?>
        <tr>
           
            <td><?php echo $pasien->kode ?></td>
            <td><?php echo $pasien->nama ?></td>
            <td><?php echo $pasien->gender ?></td>
            <td><?php echo $pasien->tmp_lahir ?></td>
            <td><?php echo $pasien->tgl_lahir ?></td>
            <td><?php echo $pasien->email ?></td>
            <td>
            <a href="<?php echo "view/$pasien->id" ?>">
            View </a> </td>
        </tr>
        <?php endforeach ?>
 </tbody>
 </table>
