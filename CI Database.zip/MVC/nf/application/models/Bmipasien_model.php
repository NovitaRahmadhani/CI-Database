<?php
class Bmipasien_model extends CI_Model {
    public $id;
    public $tanggal;
    public $pasien;
    public $bmi;
    
}
